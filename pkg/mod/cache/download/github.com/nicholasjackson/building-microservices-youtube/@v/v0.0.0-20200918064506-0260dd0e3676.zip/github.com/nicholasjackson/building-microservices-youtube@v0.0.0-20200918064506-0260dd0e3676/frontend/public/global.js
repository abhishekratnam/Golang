window.global = {
    api_location: 'http://localhost:9090',
    files_location: 'http://localhost:9091'
}